# HTTP API Factum

Базовый адрес локального запуска: `http://127.0.0.1:3000`. Авторизации нет. Методы предназначены для локального прототипа; публичный доступ к ним открывает общую историю и возможность её удаления.

## POST /api/analyze

Создаёт анализ и возвращает **поток SSE**, а не единый JSON-объект.

```bash
curl -N http://127.0.0.1:3000/api/analyze \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://example.com/public-health-article","mode":"RESEARCH"}'
```

URL в примере обозначает место публичной статьи; фактическую публикацию подставляет пользователь.

| Поле | Тип | Поведение |
| --- | --- | --- |
| `url` | string | Обязательная непустая ссылка; дальнейшая проверка адреса выполняется в конвейере |
| `mode` | string | `RESEARCH` включает расширенный поиск; любое другое значение, включая отсутствие поля, выбирает `CONTROLLED` |

Некорректный JSON или отсутствующий URL дают HTTP `400` с `{ "error": "..." }`. После открытия потока ошибки анализа передаются событием `error`; HTTP `200` не доказывает успешное завершение.

Формат сообщения:

```text
data: {"type":"stage","stage":"searching_sources","status":"active"}

```

Реальные сообщения содержат полную строку `data: ...` и пустую строку-разделитель. Пример комментария keep-alive, отправляемого каждые 15 секунд во время работы:

```text
: heartbeat

```

| `type` | Поля |
| --- | --- |
| `stage` | `stage`, `status`, необязательное `detail` |
| `log` | `level`: `info` / `warn` / `error`; `message` |
| `claims` | `claims`: массив фактов |
| `sources` | `sources`: массив источников; может обновляться после контраргументов |
| `evidence` | `evidence`: массив цитат и связей |
| `report` | `report`, `claims`, `verdicts`, `sources`, `evidence`, `document` |
| `error` | `message`, необязательное `stage` |
| `done` | `projectId` |

Статусы этапов: `pending`, `active`, `done`, `skipped`, `failed`. Этап поиска может завершиться с ошибкой, а обработка продолжится с ограниченным результатом.

Блокировка одновременного запуска возвращает событие `error` с этапом `queued`; отдельного HTTP `429` и реальной очереди нет. Закрытие клиентского потока пока не гарантирует серверную отмену.

## GET /api/health

Проверяет OpenAI-совместимый `/models`, поисковый запрос и выполнение `SELECT 1` в базе.

```bash
curl -sS http://127.0.0.1:3000/api/health
```

Структура ответа:

```json
{
  "llm": {
    "ready": true,
    "backend": "ollama",
    "backendLabel": "Ollama (local)",
    "model": "qwen2.5:0.5b",
    "baseUrl": "http://127.0.0.1:11434/v1"
  },
  "db": { "ready": true },
  "web": { "ready": true, "backend": "Bing (no API key) + direct HTTP" },
  "config": { "trustedSourcesCount": 24, "limits": {} }
}
```

Это пример структуры успешного ответа, не результат живой проверки на дату документа. В реальном ответе `limits` содержит параметры из `config.ts`, а при проблемах у компонентов появляется `error`.

Проверяйте `ready` и `error` каждого компонента. Доступность `/models` не подтверждает наличие нужного тега модели, её способность выполнять JSON-задания или медицинское качество. Проверка базы `SELECT 1` не проверяет целостность всех прикладных таблиц.

## GET /api/history

Возвращает до 50 последних запусков по убыванию времени создания:

```json
{
  "projects": [{
    "id": "project-id",
    "url": "https://example.com/article",
    "mode": "RESEARCH",
    "status": "completed",
    "createdAt": "2026-10-17T07:00:00.000Z",
    "overallVerdict": "INSUFFICIENT_EVIDENCE",
    "overallConfidence": 0,
    "claimCount": 3
  }]
}
```

`overallVerdict` и `overallConfidence` могут быть `null`, если итог ещё не сохранён. Статусы запуска: `running`, `completed`, `failed`.

## GET /api/history/{id}

Возвращает сохранённый `AnalysisResult`: сведения о запуске, документ, факты, источники, доказательства, вердикты и отчёт. Для неизвестного ID возвращает HTTP `404` и `{ "error": "Проект не найден." }`.

Схемы объектов: `src/lib/factcheck/types.ts`. Это сохранённый снимок, а не новая проверка источников.

## DELETE /api/history?id={id}

Удаляет запуск с каскадным удалением связанных записей.

```bash
curl -X DELETE 'http://127.0.0.1:3000/api/history?id=PROJECT_ID'
```

Успех: `{ "ok": true }`. Нет параметра `id`: HTTP `400`. Ошибка удаления или неизвестный ID: HTTP `404`. Файловые резервные копии базы этим методом не очищаются.
